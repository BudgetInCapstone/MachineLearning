## Install Dependencies:
1. pip install fastapi 
2. pip install "uvicorn[standard]"

## Run: 
python -m uvicorn main:app --reload


This files is for updating database with recommendations results

